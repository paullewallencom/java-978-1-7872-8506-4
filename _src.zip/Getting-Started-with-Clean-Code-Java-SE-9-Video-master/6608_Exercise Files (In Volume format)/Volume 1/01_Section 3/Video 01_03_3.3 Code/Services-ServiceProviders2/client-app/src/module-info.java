
/**
 * Author: mohamed Taman
 * Packt publishing 2018
 */
module client.app {

    requires message.service.api;
}