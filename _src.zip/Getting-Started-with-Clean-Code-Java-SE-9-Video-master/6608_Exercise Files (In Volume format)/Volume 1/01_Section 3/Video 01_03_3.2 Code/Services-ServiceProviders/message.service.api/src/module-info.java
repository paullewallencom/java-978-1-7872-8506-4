import message.service.MessageService;

/**
 * Author: mohamed Taman
 * Packt publishing 2018
 */
module message.service.api {

    exports message.service ;

    uses MessageService;

}