package package2;

public class class2 {
}
