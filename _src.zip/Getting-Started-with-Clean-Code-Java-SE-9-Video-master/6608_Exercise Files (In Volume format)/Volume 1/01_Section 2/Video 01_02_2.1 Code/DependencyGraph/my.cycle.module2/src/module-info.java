
module my.cycle.module2 {

    exports package2;
    requires my.cycle.module1;
}