
module module.graph.test {

    requires java.desktop;
}