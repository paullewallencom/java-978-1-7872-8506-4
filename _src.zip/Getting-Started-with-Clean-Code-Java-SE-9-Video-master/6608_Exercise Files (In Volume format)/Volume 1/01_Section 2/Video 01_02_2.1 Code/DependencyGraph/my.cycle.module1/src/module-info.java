
module my.cycle.module1 {

    exports package1;
    requires my.cycle.module2;
}