
module my.module {
    requires my.module;
}