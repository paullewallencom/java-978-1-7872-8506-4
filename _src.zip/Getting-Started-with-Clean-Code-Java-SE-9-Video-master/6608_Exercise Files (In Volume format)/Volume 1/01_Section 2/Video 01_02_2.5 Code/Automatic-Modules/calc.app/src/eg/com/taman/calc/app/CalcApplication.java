package eg.com.taman.calc.app;

import static eg.com.taman.calc.Calculator.*;

public class CalcApplication {


    public static void main(String[] args) {

        Double sum = add(4, 7);

        System.out.println("The sum is: " + sum);
    }


}
