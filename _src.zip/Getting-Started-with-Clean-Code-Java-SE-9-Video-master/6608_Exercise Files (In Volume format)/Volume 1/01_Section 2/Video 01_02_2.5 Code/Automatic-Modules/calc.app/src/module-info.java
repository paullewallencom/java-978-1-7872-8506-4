module calc.app {

    requires easy.calc;

}