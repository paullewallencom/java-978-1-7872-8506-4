package eg.com.taman.hello;

public class HelloWorldApp {

    public static void main(String[] args) {

        System.out.println("\n Hello world to Java SE 9 Platform Module System! \n");
    }
}
