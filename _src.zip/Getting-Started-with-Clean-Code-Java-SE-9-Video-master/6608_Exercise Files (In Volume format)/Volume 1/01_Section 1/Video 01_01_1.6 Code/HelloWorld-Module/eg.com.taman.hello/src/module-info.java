module eg.com.taman.hello {
    requires java.base;
}