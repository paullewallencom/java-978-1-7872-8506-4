module eg.com.taman.widget {

    exports eg.com.taman.support;
    requires transitive eg.org.taman.data;
}