package eg.org.taman.data.type;

public enum Type {

    XML,
    JSON,
    STRING
}
