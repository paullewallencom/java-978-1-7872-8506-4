module eg.org.taman.data {

    exports eg.org.taman.data;
    exports eg.org.taman.data.type to eg.com.taman.widget;
}