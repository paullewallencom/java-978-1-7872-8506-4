module eg.com.taman.client {

    requires eg.com.taman.widget;

}