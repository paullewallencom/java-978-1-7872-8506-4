package packt.module.hello;

import java.util.logging.Logger;

/**
 * Created by mohamed_taman on 5/11/17.
 */
public class HelloWorldApp {

   private static Logger log = Logger.getLogger(HelloWorldApp.class.getName());

    public static void main(String[] args) {

        log.info("Hello World with Java SE 9 modules");

    }
}
