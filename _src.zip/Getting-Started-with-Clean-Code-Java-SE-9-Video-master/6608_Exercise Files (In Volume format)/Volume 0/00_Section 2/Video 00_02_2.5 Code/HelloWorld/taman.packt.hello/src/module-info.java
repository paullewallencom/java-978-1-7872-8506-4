/**
 * Created by mohamed_taman on 5/11/17.
 */
module taman.packt.hello {
    requires java.logging;
}